// Footer.jsx — final CTA + footer.

(function () {
  function Footer() {
    return (
      <>
        <section id="upload" className="lp-section lp-cta-sec">
          <div className="lp-cta-card">
            <div className="lp-cta-grid" aria-hidden="true" />
            <div className="lp-cta-inner">
              <span className="lp-eyebrow lp-mono">04 · ship it</span>
              <h2 className="lp-cta-title">
                <span className="lp-serif">Bring a video.</span>{" "}
                <span className="lp-serif lp-serif-accent">Leave with a twin.</span>
              </h2>
              <p className="lp-cta-sub">
                Mobile-first. Works on iPhone Safari, Pixel, desktop. No accounts, no setup.
              </p>
              <div className="lp-hero-cta">
                <a className="lp-btn lp-btn-primary lp-btn-lg" href="#">
                  Drop a video <span className="lp-btn-arrow">→</span>
                </a>
                <a className="lp-btn lp-btn-ghost lp-btn-lg" href="#viewer">
                  View demo scene
                </a>
              </div>
            </div>
          </div>
        </section>

        <footer className="lp-footer">
          <div className="lp-footer-l">
            <div className="lp-brand-mark lp-brand-mark--sm" />
            <span className="lp-mono lp-muted">spatiality · render branch · v0.4.2</span>
          </div>
          <div className="lp-footer-links lp-mono">
            <a href="#">github</a>
            <a href="#">render.yaml</a>
            <a href="#">logfire</a>
            <a href="#">CLAUDE.md</a>
          </div>
        </footer>
      </>
    );
  }
  window.LPFooter = Footer;
})();
