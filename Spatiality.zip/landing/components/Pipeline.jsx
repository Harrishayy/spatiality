// Pipeline.jsx — the modular pipeline section. Mirrors
// web/app/components/PipelineProgress.tsx exactly: stage order, status
// dots, monospace duration, three-cell stats grid. Adds a live "logs"
// terminal to the right that streams Logfire span entries.

(function () {
  const { useState, useEffect, useRef } = React;

  // Stage spec mirrors STAGE_ORDER + LABEL from PipelineProgress.tsx.
  // We deliberately keep the same wording so the marketing surface
  // matches what users see inside the app.
  const STAGES = [
    {
      key: "capture",
      label: "Capture",
      sub: "frames + audio extracted",
      duration: "4.1s",
      extra: "120 frames",
    },
    {
      key: "poses",
      label: "Reconstruction (VGGT)",
      sub: "poses + dense surfels",
      duration: "38.7s",
      extra: "120 / 240 frames",
    },
    {
      key: "splat",
      label: "Splat (cluster)",
      sub: "voxel-downsampled to splat.ply",
      duration: "6.3s",
      extra: "412 K clusters",
      hidden: true, // matches the comment in PipelineProgress.tsx
    },
    {
      key: "segmentation",
      label: "Segmentation",
      sub: "SAM 3.1 + VLM labels",
      duration: "11.2s",
      extra: "27 obj",
    },
  ];

  // Logfire-style spans. Names + metadata follow plans/modules/08_observability.md
  // ordering so demo narration matches what's printed.
  const SPAN_LOG = [
    ["00.00", "info", "agent.boot", "scene_id=living_room_03"],
    ["00.02", "info", "capture.start", "src=ray-ban-gen2.mp4 size=84.2MB"],
    ["00.18", "info", "capture.frames", "extracted=240 fps=30"],
    ["04.10", "ok", "capture.done", "duration=4.1s"],
    ["04.11", "info", "infer.poses.start", "model=vggt-1b dtype=fp16"],
    ["12.40", "info", "infer.poses.progress", "frames=80/120 conf=0.91"],
    ["28.30", "info", "infer.poses.progress", "frames=120/120 conf=0.94"],
    ["42.80", "ok", "infer.poses.done", "surfels=2.41M dur=38.7s"],
    ["42.82", "info", "splat.cluster.start", "voxel=0.025"],
    ["49.10", "ok", "splat.cluster.done", "clusters=412173 dur=6.3s"],
    ["49.11", "info", "segment.sam31.start", "device=A100 batch=8"],
    ["54.40", "info", "segment.sam31.masks", "kept=89 / 412 (>0.6 iou)"],
    ["58.20", "info", "agent.gateway.label", "via=pydantic-ai/anthropic"],
    ["60.30", "ok", "segment.label.done", "objects=27 dur=11.2s"],
    ["60.31", "ok", "manifest.write", "status=ready"],
    ["60.32", "ok", "agent.ready", "where_am_i ≤3s"],
  ];

  function Pipeline() {
    return (
      <section id="pipeline" className="lp-section lp-pipeline">
        <SectionHeader
          eyebrow="01 · pipeline"
          title={
            <>
              From <em>video</em> to <em>twin</em> in <em>~90s</em>.
            </>
          }
          sub="Every stage is a swappable module. Filesystem-only artifacts. Logfire spans on every call."
        />

        <div className="lp-pipeline-grid">
          <StagePanel />
          <LogPanel />
        </div>

        <StatsRow />
      </section>
    );
  }

  function StagePanel() {
    return (
      <div className="lp-card lp-stage-panel">
        <div className="lp-card-head">
          <div className="lp-card-head-l">
            <h3 className="lp-card-title">Pipeline</h3>
            <span className="lp-mono lp-muted">scene_living_room_03</span>
          </div>
          <span className="lp-status-pill lp-status-pill--ok">
            <span className="lp-status-dot lp-status-dot--ok" />
            ready · 60.3s
          </span>
        </div>

        <ol className="lp-stage-list">
          {STAGES.filter((s) => !s.hidden).map((s) => (
            <li key={s.key} className="lp-stage-row">
              <span className="lp-stage-dot lp-stage-dot--complete" />
              <div className="lp-stage-meta">
                <div className="lp-stage-label">{s.label}</div>
                <div className="lp-stage-sub lp-mono">{s.sub}</div>
              </div>
              <div className="lp-stage-numbers">
                <span className="lp-mono lp-muted">{s.extra}</span>
                <span className="lp-mono lp-stage-dur">{s.duration}</span>
              </div>
            </li>
          ))}
        </ol>

        <div className="lp-stage-foot">
          <span className="lp-mono lp-muted">
            artifacts/scenes/living_room_03/
          </span>
          <div className="lp-stage-foot-files">
            <FileChip name="manifest.json" />
            <FileChip name="annotations.json" />
            <FileChip name="splat.ply" />
            <FileChip name="points.ply" />
          </div>
        </div>
      </div>
    );
  }

  function FileChip({ name }) {
    return (
      <span className="lp-file-chip">
        <span className="lp-file-chip-icon">▤</span>
        <span className="lp-mono">{name}</span>
      </span>
    );
  }

  function LogPanel() {
    const [count, setCount] = useState(SPAN_LOG.length);
    const tailRef = useRef(null);

    // Looping playback so the log feels live without lying.
    useEffect(() => {
      let i = 0;
      setCount(0);
      const id = setInterval(() => {
        i += 1;
        if (i > SPAN_LOG.length) {
          i = 0;
          setCount(0);
          return;
        }
        setCount(i);
      }, 380);
      return () => clearInterval(id);
    }, []);

    useEffect(() => {
      if (tailRef.current) tailRef.current.scrollTop = 1e6;
    }, [count]);

    const visible = SPAN_LOG.slice(0, count);

    return (
      <div className="lp-card lp-log-panel">
        <div className="lp-log-head">
          <div className="lp-log-traffic">
            <span />
            <span />
            <span />
          </div>
          <span className="lp-mono lp-muted">
            logfire · agent + pipeline · tail -f
          </span>
          <span className="lp-mono lp-muted">{visible.length} spans</span>
        </div>
        <div className="lp-log-body" ref={tailRef}>
          {visible.map((row, idx) => (
            <div key={idx} className="lp-log-row">
              <span className="lp-mono lp-log-time">{row[0]}</span>
              <span
                className={
                  "lp-log-level lp-mono lp-log-level--" + row[1]
                }
              >
                {row[1]}
              </span>
              <span className="lp-mono lp-log-name">{row[2]}</span>
              <span className="lp-mono lp-log-meta">{row[3]}</span>
            </div>
          ))}
          <div className="lp-log-cursor lp-mono">
            <span className="lp-log-prompt">›</span>
            <span className="lp-log-blink">_</span>
          </div>
        </div>
      </div>
    );
  }

  function StatsRow() {
    return (
      <div className="lp-stats-row">
        <Cell label="frames" value="120 / 240" />
        <Cell label="objects" value="27" />
        <Cell label="points" value="2.41 M" />
        <Cell label="splat" value="48 MB" />
      </div>
    );
  }

  function Cell({ label, value }) {
    return (
      <div className="lp-stats-cell">
        <div className="lp-stats-value lp-mono">{value}</div>
        <div className="lp-stats-label lp-mono">{label}</div>
      </div>
    );
  }

  function SectionHeader({ eyebrow, title, sub }) {
    return (
      <div className="lp-section-head">
        <span className="lp-eyebrow lp-mono">{eyebrow}</span>
        <h2 className="lp-section-title">{title}</h2>
        {sub ? <p className="lp-section-sub">{sub}</p> : null}
      </div>
    );
  }

  window.LPPipeline = Pipeline;
  window.LPSectionHeader = SectionHeader;
})();
