// MeshHero.jsx — Three.js scene that granularly builds a 3D mesh from
// scattered points → triangulated edges → solid wireframe → splatted surfels.
// Loops forever. Designed to sit full-bleed under the hero copy.
//
// In the Next.js port this becomes web/app/components/landing/MeshHero.tsx
// and is mounted from web/app/page.tsx (render branch).

(function () {
  function MeshHero({ paused }) {
    const ref = React.useRef(null);

    React.useEffect(() => {
      const host = ref.current;
      if (!host || !window.THREE) return;
      const THREE = window.THREE;

      // ───── scene / camera / renderer ───────────────────────────────────
      const scene = new THREE.Scene();
      scene.fog = new THREE.FogExp2(0x1a0e14, 0.06);

      const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 100);
      camera.position.set(6.2, 3.4, 6.6);
      camera.lookAt(0, 0.2, 0);

      const renderer = new THREE.WebGLRenderer({
        antialias: true,
        alpha: true,
      });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      renderer.setClearColor(0x000000, 0);
      host.appendChild(renderer.domElement);

      // ───── seeded room geometry (sample of a real "twin") ──────────────
      // We pre-generate a target point cloud distributed across a few
      // implicit surfaces — floor, back wall, side wall, a couch-sized
      // box and a table — so the build-up reads as an actual room.
      const N = 1400;
      const targets = new Float32Array(N * 3);
      const labels = new Uint8Array(N); // 0..4 for color tinting

      function rand(min, max) {
        return min + Math.random() * (max - min);
      }
      function jitter(v, j) {
        return v + (Math.random() - 0.5) * j;
      }

      let i = 0;
      // floor 6x6
      for (; i < 380; i++) {
        targets[i * 3 + 0] = rand(-3, 3);
        targets[i * 3 + 1] = jitter(0, 0.04);
        targets[i * 3 + 2] = rand(-3, 3);
        labels[i] = 0;
      }
      // back wall
      for (; i < 600; i++) {
        targets[i * 3 + 0] = rand(-3, 3);
        targets[i * 3 + 1] = rand(0, 2.6);
        targets[i * 3 + 2] = jitter(-3, 0.05);
        labels[i] = 1;
      }
      // side wall
      for (; i < 780; i++) {
        targets[i * 3 + 0] = jitter(-3, 0.05);
        targets[i * 3 + 1] = rand(0, 2.6);
        targets[i * 3 + 2] = rand(-3, 3);
        labels[i] = 1;
      }
      // couch box (centered roughly at -1.2,0.45,1.0 ; 2.0 x 0.9 x 0.9)
      for (; i < 1020; i++) {
        const cx = -1.2,
          cy = 0.45,
          cz = 1.0;
        const sx = 1.0,
          sy = 0.45,
          sz = 0.45;
        const face = Math.floor(Math.random() * 5); // skip bottom face
        let x = cx + rand(-sx, sx);
        let y = cy + rand(-sy, sy);
        let z = cz + rand(-sz, sz);
        if (face === 0) y = cy + sy; // top
        else if (face === 1) x = cx - sx;
        else if (face === 2) x = cx + sx;
        else if (face === 3) z = cz - sz;
        else if (face === 4) z = cz + sz;
        targets[i * 3 + 0] = jitter(x, 0.03);
        targets[i * 3 + 1] = jitter(y, 0.03);
        targets[i * 3 + 2] = jitter(z, 0.03);
        labels[i] = 2;
      }
      // table
      for (; i < 1200; i++) {
        const cx = 1.4,
          cy = 0.7,
          cz = -0.6;
        const sx = 0.7,
          sy = 0.05,
          sz = 0.5;
        const face = Math.floor(Math.random() * 5);
        let x = cx + rand(-sx, sx);
        let y = cy + rand(-sy, sy);
        let z = cz + rand(-sz, sz);
        if (face === 0) y = cy + sy;
        else if (face === 1) x = cx - sx;
        else if (face === 2) x = cx + sx;
        else if (face === 3) z = cz - sz;
        else if (face === 4) z = cz + sz;
        targets[i * 3 + 0] = jitter(x, 0.025);
        targets[i * 3 + 1] = jitter(y, 0.025);
        targets[i * 3 + 2] = jitter(z, 0.025);
        labels[i] = 3;
      }
      // table legs (4 small clusters)
      const legs = [
        [0.85, 0.35, -0.15],
        [0.85, 0.35, -1.05],
        [1.95, 0.35, -0.15],
        [1.95, 0.35, -1.05],
      ];
      for (let li = 0; li < 4; li++, i += 50) {
        for (let k = 0; k < 50; k++) {
          targets[(i + k) * 3 + 0] = jitter(legs[li][0], 0.03);
          targets[(i + k) * 3 + 1] = jitter(legs[li][1], 0.32);
          targets[(i + k) * 3 + 2] = jitter(legs[li][2], 0.03);
          labels[i + k] = 3;
        }
      }
      // total used: 1400 (we over-allocated; tail is zeros and harmless if
      // we cap geometry to actually filled count)
      const used = i;

      // origin scatter (where points come "from")
      const origins = new Float32Array(used * 3);
      for (let k = 0; k < used; k++) {
        origins[k * 3 + 0] = rand(-7, 7);
        origins[k * 3 + 1] = rand(-3, 5);
        origins[k * 3 + 2] = rand(-7, 7);
      }

      // ───── points ──────────────────────────────────────────────────────
      const positions = new Float32Array(used * 3);
      const colors = new Float32Array(used * 3);
      // sunset palette — coral/apricot/gold/magenta, warm sand floor, plum walls
      const palette = [
        [0.95, 0.78, 0.62], // floor — warm sand (#f2c79e)
        [0.55, 0.30, 0.42], // walls — dusk plum (#8c4d6a)
        [1.0,  0.42, 0.29], // couch — coral accent-500 (#ff6b4a)
        [1.0,  0.62, 0.43], // table — apricot accent-400 (#ff9d6f)
        [1.0,  0.82, 0.55], // misc — soft gold accent-300 (#ffd29c)
      ];
      for (let k = 0; k < used; k++) {
        const c = palette[labels[k]] || palette[0];
        colors[k * 3 + 0] = c[0];
        colors[k * 3 + 1] = c[1];
        colors[k * 3 + 2] = c[2];
      }

      const pointGeom = new THREE.BufferGeometry();
      pointGeom.setAttribute(
        "position",
        new THREE.BufferAttribute(positions, 3),
      );
      pointGeom.setAttribute("color", new THREE.BufferAttribute(colors, 3));

      const pointMat = new THREE.PointsMaterial({
        size: 0.038,
        vertexColors: true,
        transparent: true,
        opacity: 0.9,
        depthWrite: false,
        sizeAttenuation: true,
      });
      const points = new THREE.Points(pointGeom, pointMat);
      scene.add(points);

      // ───── triangulated edges (procedural mesh) ────────────────────────
      // Pick a sparse set of triangles between nearby points within the
      // same label group, draw their edges as lines that fade in.
      const edgeIndices = [];
      const groups = [[], [], [], [], []];
      for (let k = 0; k < used; k++) groups[labels[k]].push(k);

      function pickTriangles(group, count) {
        for (let t = 0; t < count; t++) {
          if (group.length < 3) break;
          const a = group[Math.floor(Math.random() * group.length)];
          // Find two nearest-ish neighbors via random-from-group with
          // distance gate (cheap, looks fine in motion)
          const tries = 6;
          let b = -1,
            c = -1;
          let bd = 999,
            cd = 999;
          const ax = targets[a * 3],
            ay = targets[a * 3 + 1],
            az = targets[a * 3 + 2];
          for (let q = 0; q < tries; q++) {
            const cand = group[Math.floor(Math.random() * group.length)];
            if (cand === a) continue;
            const dx = targets[cand * 3] - ax;
            const dy = targets[cand * 3 + 1] - ay;
            const dz = targets[cand * 3 + 2] - az;
            const d = dx * dx + dy * dy + dz * dz;
            if (d < bd) {
              cd = bd;
              c = b;
              bd = d;
              b = cand;
            } else if (d < cd) {
              cd = d;
              c = cand;
            }
          }
          if (b >= 0 && c >= 0 && b !== c) {
            edgeIndices.push(a, b, b, c, c, a);
          }
        }
      }
      pickTriangles(groups[0], 90);
      pickTriangles(groups[1], 110);
      pickTriangles(groups[2], 120);
      pickTriangles(groups[3], 90);

      const edgePos = new Float32Array(edgeIndices.length * 3);
      const edgeCol = new Float32Array(edgeIndices.length * 3);
      for (let e = 0; e < edgeIndices.length; e++) {
        const idx = edgeIndices[e];
        edgePos[e * 3 + 0] = targets[idx * 3 + 0];
        edgePos[e * 3 + 1] = targets[idx * 3 + 1];
        edgePos[e * 3 + 2] = targets[idx * 3 + 2];
        const c = palette[labels[idx]] || palette[0];
        edgeCol[e * 3 + 0] = c[0];
        edgeCol[e * 3 + 1] = c[1];
        edgeCol[e * 3 + 2] = c[2];
      }
      const edgeGeom = new THREE.BufferGeometry();
      edgeGeom.setAttribute(
        "position",
        new THREE.BufferAttribute(edgePos, 3),
      );
      edgeGeom.setAttribute("color", new THREE.BufferAttribute(edgeCol, 3));
      const edgeMat = new THREE.LineBasicMaterial({
        vertexColors: true,
        transparent: true,
        opacity: 0,
      });
      const edges = new THREE.LineSegments(edgeGeom, edgeMat);
      scene.add(edges);

      // ───── annotation pins (3D billboards) ─────────────────────────────
      const pinSpec = [
        { label: "couch", pos: [-1.2, 1.05, 1.0] },
        { label: "table", pos: [1.4, 0.95, -0.6] },
        { label: "floor", pos: [0.6, 0.05, 0.6] },
      ];
      const pins = pinSpec.map((p) => {
        const g = new THREE.SphereGeometry(0.045, 12, 12);
        const m = new THREE.MeshBasicMaterial({
          color: 0xffb347,
          transparent: true,
          opacity: 0,
        });
        const s = new THREE.Mesh(g, m);
        s.position.set(p.pos[0], p.pos[1], p.pos[2]);
        scene.add(s);
        // halo
        const hg = new THREE.RingGeometry(0.07, 0.1, 24);
        const hm = new THREE.MeshBasicMaterial({
          color: 0xff9d6f,
          transparent: true,
          opacity: 0,
          side: THREE.DoubleSide,
        });
        const halo = new THREE.Mesh(hg, hm);
        halo.position.copy(s.position);
        scene.add(halo);
        return { core: s, halo, label: p.label, pos: p.pos };
      });

      // overlay 2D labels (DOM, reprojected) — lighter touch than sprites
      const labelLayer = document.createElement("div");
      labelLayer.style.cssText =
        "position:absolute;inset:0;pointer-events:none;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;";
      host.appendChild(labelLayer);
      const labelEls = pinSpec.map((p) => {
        const el = document.createElement("div");
        el.textContent = p.label;
        el.style.cssText = [
          "position:absolute",
          "padding:2px 8px",
          "border:1px solid rgba(255,157,111,.45)",
          "background:rgba(38,21,32,.88)",
          "color:#ffd29c",
          "font-size:10px",
          "letter-spacing:.08em",
          "text-transform:uppercase",
          "border-radius:999px",
          "transform:translate(-50%,-50%)",
          "white-space:nowrap",
          "opacity:0",
          "transition:opacity 240ms ease",
          "backdrop-filter:blur(4px)",
        ].join(";");
        labelLayer.appendChild(el);
        return el;
      });

      // ───── resize ──────────────────────────────────────────────────────
      function fit() {
        const r = host.getBoundingClientRect();
        renderer.setSize(r.width, r.height, false);
        camera.aspect = r.width / r.height;
        camera.updateProjectionMatrix();
      }
      fit();
      const ro = new ResizeObserver(fit);
      ro.observe(host);

      // ───── animation loop ──────────────────────────────────────────────
      // 4 phases per cycle (8s total):
      //   0.00–0.30  scatter→points  (assemble)
      //   0.30–0.55  edges fade in   (mesh)
      //   0.55–0.80  edges hold, point sizes grow (splat)
      //   0.80–1.00  pins + labels reveal, then dissolve back
      const CYCLE_MS = 8000;
      const start = performance.now();
      let raf = 0;

      const tmpV = new THREE.Vector3();

      function easeOut(t) {
        return 1 - Math.pow(1 - t, 3);
      }
      function smooth(t) {
        return t * t * (3 - 2 * t);
      }

      function tick() {
        const now = performance.now();
        const elapsed = (now - start) % CYCLE_MS;
        const u = elapsed / CYCLE_MS; // 0..1

        // assemble phase
        let aP = 0;
        if (u < 0.3) aP = easeOut(u / 0.3);
        else if (u < 0.95) aP = 1;
        else aP = 1 - smooth((u - 0.95) / 0.05);

        const posAttr = pointGeom.attributes.position;
        for (let k = 0; k < used; k++) {
          const ox = origins[k * 3 + 0];
          const oy = origins[k * 3 + 1];
          const oz = origins[k * 3 + 2];
          const tx = targets[k * 3 + 0];
          const ty = targets[k * 3 + 1];
          const tz = targets[k * 3 + 2];
          // per-point delay so points arrive in waves
          const delay = (k % 12) / 60; // up to ~0.2
          const local = Math.max(0, Math.min(1, (u - delay) / 0.3));
          const a = u < 0.3 ? easeOut(local) : aP;
          posAttr.array[k * 3 + 0] = ox + (tx - ox) * a;
          posAttr.array[k * 3 + 1] = oy + (ty - oy) * a;
          posAttr.array[k * 3 + 2] = oz + (tz - oz) * a;
        }
        posAttr.needsUpdate = true;

        // edges
        let eOp = 0;
        if (u >= 0.3 && u < 0.55) eOp = (u - 0.3) / 0.25;
        else if (u >= 0.55 && u < 0.8) eOp = 1 - (u - 0.55) / 0.5;
        else if (u >= 0.8 && u < 0.95) eOp = 0.5 - (u - 0.8) / 0.3;
        else eOp = 0;
        edgeMat.opacity = Math.max(0, Math.min(0.7, eOp));

        // splat phase: grow point size + opacity
        let splat = 0;
        if (u >= 0.55 && u < 0.95) splat = (u - 0.55) / 0.4;
        pointMat.size = 0.038 + 0.022 * smooth(splat);
        pointMat.opacity = 0.9 + 0.1 * splat;

        // pins
        let pinOp = 0;
        if (u >= 0.7 && u < 0.95) pinOp = (u - 0.7) / 0.25;
        else if (u >= 0.95) pinOp = 1 - (u - 0.95) / 0.05;
        pinOp = Math.max(0, Math.min(1, pinOp));
        for (let p = 0; p < pins.length; p++) {
          pins[p].core.material.opacity = pinOp;
          pins[p].halo.material.opacity = pinOp * 0.5;
          pins[p].halo.scale.setScalar(1 + 0.6 * Math.sin(now * 0.004 + p));
          pins[p].halo.lookAt(camera.position);
        }

        // gentle camera orbit
        const t = now * 0.00015;
        camera.position.x = Math.cos(t) * 7.0;
        camera.position.z = Math.sin(t) * 7.0;
        camera.position.y = 3.0 + Math.sin(t * 1.3) * 0.4;
        camera.lookAt(0, 0.4, 0);

        // reproject pins to DOM
        const r = host.getBoundingClientRect();
        for (let p = 0; p < pins.length; p++) {
          tmpV.set(pins[p].pos[0], pins[p].pos[1] + 0.18, pins[p].pos[2]);
          tmpV.project(camera);
          const x = (tmpV.x * 0.5 + 0.5) * r.width;
          const y = (-tmpV.y * 0.5 + 0.5) * r.height;
          labelEls[p].style.left = x + "px";
          labelEls[p].style.top = y + "px";
          labelEls[p].style.opacity = String(pinOp * 0.95);
        }

        renderer.render(scene, camera);
        raf = requestAnimationFrame(tick);
      }
      raf = requestAnimationFrame(tick);

      return () => {
        cancelAnimationFrame(raf);
        ro.disconnect();
        renderer.dispose();
        host.removeChild(renderer.domElement);
        host.removeChild(labelLayer);
      };
    }, []);

    return React.createElement("div", {
      ref,
      style: {
        position: "absolute",
        inset: 0,
        pointerEvents: "none",
      },
    });
  }

  window.MeshHero = MeshHero;
})();
