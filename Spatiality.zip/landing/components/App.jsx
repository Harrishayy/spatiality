// App.jsx — top-level composition. Ports cleanly to web/app/page.tsx
// on the render branch:
//
//   import { LandingHeader } from "@/components/landing/Header";
//   import { LandingHero } from "@/components/landing/Hero";
//   import { LandingPipeline } from "@/components/landing/Pipeline";
//   import { LandingViewer } from "@/components/landing/Viewer";
//   import { LandingModules } from "@/components/landing/Modules";
//   import { LandingFooter } from "@/components/landing/Footer";
//
// Each component is self-contained; styles live in landing.css which
// becomes app/styles/landing.css.

(function () {
  function App() {
    return (
      <>
        <window.LPHeader />
        <window.LPHero />
        <main className="lp-main">
          <window.LPPipeline />
          <window.LPViewer />
          <window.LPModules />
          <window.LPFooter />
        </main>
      </>
    );
  }

  const root = ReactDOM.createRoot(document.getElementById("app"));
  root.render(<App />);
})();
