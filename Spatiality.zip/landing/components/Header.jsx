// Header.jsx — refined top nav. Three-region layout: brand left,
// pill nav center (segmented), CTA cluster right. The status pill is
// kept but loses its mono caption (it was noise) and becomes a tiny
// dot+label so it reads as ambient telemetry, not chrome.

(function () {
  function Header() {
    return (
      <header className="lp-header">
        <div className="lp-header-l">
          <a className="lp-brand" href="#">
            <div className="lp-brand-mark" />
            <span className="lp-brand-title">Spatiality</span>
          </a>
          <span className="lp-brand-divider" aria-hidden="true" />
          <span className="lp-mono lp-muted lp-brand-tag">
            glasses → 3D twin
          </span>
        </div>

        <nav className="lp-nav" aria-label="primary">
          <a href="#pipeline">Pipeline</a>
          <a href="#viewer">Viewer</a>
          <a href="#agent">Agent</a>
          <a href="#docs">Docs</a>
          <span className="lp-nav-divider" aria-hidden="true" />
          <a href="#changelog" className="lp-nav-meta">
            <span className="lp-nav-meta-dot" />
            v0.4.2
          </a>
        </nav>

        <div className="lp-header-r">
          <a className="lp-btn lp-btn-ghost lp-btn-sm" href="#viewer">
            Live demo
          </a>
          <a className="lp-btn lp-btn-primary lp-btn-sm" href="#upload">
            Upload video
            <span className="lp-btn-arrow">→</span>
          </a>
        </div>
      </header>
    );
  }
  window.LPHeader = Header;
})();

